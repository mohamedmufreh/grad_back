import express from 'express';
import bodyParser from 'body-parser';
import dotenv from 'dotenv';
dotenv.config();

import usersRoutes from './handlers/users';
import vehiclesRoutes from './handlers/vehicles';
import transactionsRoutes from './handlers/transactions';
import { transactionStore } from '../src/models/transactions';
const operations = new transactionStore();


const stripe=require('stripe')(process.env.STRIPE_SECRET);
// const bodyParser=require('body-parser')


const port = process.env.PORT;

const app: express.Application = express();
const address = `0.0.0.0:${port as string}`;

app.use(bodyParser.json());
app.use('/users', usersRoutes);
app.use('/vehicles', vehiclesRoutes);
app.use('/transactions', transactionsRoutes);
const endpointSecret = "whsec_7d39fde1103999538026af246603797255e54c3784eb32daf6e24ef7aabc2579";

app.post('/webhook',express.raw({type: 'application/json'}),(request, response) => {
  const sig = request.headers['stripe-signature'];
  const userString=JSON.stringify(request.body);
  const payload = JSON.parse(userString);
  let event;
  // console.log(`${payload}, ${sig}, ${endpointSecret}`);
  // response.status(400).json(`${request.body}, ${sig}, ${endpointSecret}`);


  try {
    event = stripe.webhooks.constructEvent(request.body, sig, endpointSecret);
    console.log(`${request.body}, ${sig}, ${endpointSecret}`);
    switch (event.type) {
      case 'payment_intent.succeeded':
        const paymentIntentSucceeded = event.data.object;
        console.log(`Payment successed`);
        // Then define and call a function to handle the event payment_intent.succeeded
        break;
      // ... handle other event types
      default:
        console.log(`Unhandled event type ${event.type}`);
    }
  } catch (err) {
    response.status(400).json(`Webhook Error: ........`);
    return;
  }





  // Handle the event
  

  // Return a 200 response to acknowledge receipt of the event
  // response.send();
});

// app.get('/webhook',express.raw({type: 'application/json'}),async(req,res)=>{
// let signingsecret="whsec_7d39fde1103999538026af246603797255e54c3784eb32daf6e24ef7aabc2579";
// const payload=req.body;
// const sig=req.headers['stripe-signature'];
// let event;
// try{
// event = await stripe.webhooks.constructEvent(payload,sig,signingsecret);
// // console.log(event.type);
// // console.log(event.data.object);
// // console.log(event.data.object.id);
// res.status(200).json("webhook succeed");
// }catch (error){
// res.status(400).json("failed in webhook............");
// }
// console.log(event.type);
// console.log(event.data.object);
// console.log(event.data.object.id);
// });


app.get('/test-api', (req, res) => {
    res.send('Server Works!');
  });
  
  app.listen(port || 3000, () => {
    console.log(`server started at localhost:${address}`);
  });
  
  export default app;












  // server.js
//
// Use this sample code to handle webhook events in your integration.
//
// 1) Paste this code into a new file (server.js)
//
// 2) Install dependencies
//   npm install stripe
//   npm install express
//
// 3) Run the server on http://localhost:4242
//   node server.js

// The library needs to be configured with your account's secret key.
// Ensure the key is kept out of any version control system you might be using.
// const stripe = require('stripe')('sk_test_...');
// const express = require('express');
// const app = express();


// This is your Stripe CLI webhook secret for testing your endpoint locally.
// const endpointSecret = "whsec_7d39fde1103999538026af246603797255e54c3784eb32daf6e24ef7aabc2579";

// app.post('/webhook', express.raw({type: 'application/json'}), (request, response) => {
//   const sig = request.headers['stripe-signature'];

//   let event;

//   try {
//     event = stripe.webhooks.constructEvent(request.body, sig, endpointSecret);
//   } catch (err) {
//     response.status(400).send(`Webhook Error: ${err.message}`);
//     return;
//   }

//   // Handle the event
//   switch (event.type) {
//     case 'payment_intent.succeeded':
//       const paymentIntentSucceeded = event.data.object;
//       // Then define and call a function to handle the event payment_intent.succeeded
//       break;
//     // ... handle other event types
//     default:
//       console.log(`Unhandled event type ${event.type}`);
//   }

//   // Return a 200 response to acknowledge receipt of the event
//   response.send();
// });

// app.listen(4242, () => console.log('Running on port 4242'));