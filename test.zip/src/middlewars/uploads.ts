import multer from 'multer';


const multerStorage =multer.diskStorage({
  destination:(req,file,cb)=>{
    cb(null,'uploads');
  },
  filename:(req,file,cb)=>{
    const ext=file.mimetype.split('/')[1];
    const fileName =`${file.originalname}-${Date.now()}.${ext}`;
    req.body.image=fileName;
    cb(null,fileName);
  },
});


const upload=multer({storage:multerStorage});


export const uploadImage=upload.single('image');

