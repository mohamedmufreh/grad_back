import jwt from 'jsonwebtoken';
import express, { Request, Response } from 'express';
import { Transaction,transactionStore } from '../models/transactions';
import dotenv from 'dotenv';
import { verifyAuthToken } from '../middlewars/verifyAuthToken';
import { verifyTokenAndAuthorization } from '../middlewars/verifyTokenAndAuthorization';
import { verifyTokenAndAdmin } from '../middlewars/verifyTokenAndAdmin';
import {  uploadImage} from '../middlewars/uploads';
import {  carType} from '../middlewars/carType';
dotenv.config();
const stripe=require('stripe')(process.env.STRIPE_SECRET);

const router = express.Router();
const operations = new transactionStore();
const gtoken = process.env.TOKEN_SECRET;
// verifyTokenAndAdmin,uploadImage
router.post('/',verifyTokenAndAdmin,uploadImage, carType,async (req: express.Request, res: express.Response) => {
    const now =new Date().toLocaleString().split(",");
    const vehicle: Transaction = {
        vehicle_id: req.body.vehicle_id,
        // vehicle_image: req.file?.filename as string,
        vehicle_image: req.body.image,
        place: req.body.place,
        adjustment_date: now[0],
        adjustment_time: now[1],
        fine: req.body.fine,
        payment_date: "notpaid",
        payment_status: "notpaid",
    };
    try {
        // console.log(`${req.file?.filename as string}  ${typeof(req.file?.filename as string)}`);
      const newVehicle = await operations.create(vehicle);
      // const token = jwt.sign({ vehicle: newVehicle }, gtoken as string);
      res.status(200).json(newVehicle);
      // res.status(200).json(req.body.fine);
    } catch (err) {
      res.status(500).json(`Cannot create the Vehicle. ${err}.`);
    }
  });
// // //   , verifyAuthToken
// , verifyTokenAndAdmin
  router.get('/' ,  async (req: Request, res: Response) => {
    try {
      const users = await operations.index();
      res.status(200).json(users);
    } catch (error) {
      res.status(500).json(`Cannot Get the transactions. ${error}.`);
    }
  });
  
  router.get('/:id/admin', verifyTokenAndAuthorization, async (req: Request, res: Response) => {
    try {
      const vehicle = await operations.show(req.params.id);
      res.status(200).json(vehicle);
    } catch (error) {
      res.status(500).json(`Cannot Get the vehicle. ${error}.`);
    }
  });
  
  router.get('/:id', verifyTokenAndAuthorization, async (req: Request, res: Response) => {
    try {
      const vehicle = await operations.showVehicleTransactions(req.params.id as unknown as string);
      res.status(200).json(vehicle);
    } catch (error) {
      res.status(500).json(`Cannot Get the User vehicles. ${error}.`);
    }
  });
  // router.put('/:id',verifyTokenAndAdmin,uploadImage, carType, async (req: Request, res: Response) => {
  //   try {
  //     const user: Transaction = {
  //       vehicle_id: req.body.license_id,
  //       vehicle_image: req.body.image,
  //       place: req.body.traffic_unit,
  //       adjustment_date: req.body.license_create_date,
  //       adjustment_time: req.body.license_expired_date,
  //       fine: req.body.manufacturer,
  //       payment_date: req.body.model,
  //       payment_status: req.body.manufacturering_year,
  //     };
  //     const newUser = await operations.update(user, req.params.id);
  //     res.status(200).json(newUser);
  //   } catch (error) {
  //     res.status(500).json(`Cannot Update the vehicle. ${error}.`);
  //   }
  // });
  router.delete('/:id', verifyTokenAndAdmin, async (req: Request, res: Response) => {
    try {
      const deleted = await operations.delete(req.params.id as unknown as number);
      res.status(200).json(deleted);
    } catch (error) {
      res.status(500).json(`Cannot Delete the vehicle. ${error}.`);
    }
  });

  router.get('/checkout-session/:id',verifyTokenAndAuthorization,async (req: Request, res: Response)=>{
    try {
      const vehicle = await operations.show(req.params.id as unknown as string);
      // res.status(200).json(vehicle.fine);
      const totalprice=vehicle.fine*1000;
      const carId=vehicle.vehicle_id;
      const session=await stripe.checkout.sessions.create({
        line_items:[{
// name:vehicle.vehicle_id,
// amount:vehicle.fine*100,
// amount:totalprice,
// currency:"egp",
// price:totalprice as unknown as string ,
// price_data:totalprice,
// quantity:1,
price_data:{
  currency:"egp",
  product_data:{
    name:`transaction ID: ${req.params.id}`,
  },
  unit_amount:totalprice,
},
quantity:1,
        }],
      mode:"payment",
      success_url: `${req.protocol}://${req.get("host")}/webhook`,
    cancel_url: `${req.protocol}://${req.get("host")}/transactions/`,
    client_reference_id:req.params.id,
      });
// const session=await stripe.charges.create({
//   amount:totalprice*100000,
//   source:"tok_visa",
//   currency:"egp"
// });
      res.status(200).json({status:"success",url:session.url,session});
    } catch (error) {
      res.status(500).json(`Cannot create the session for the transaction. ${error}.`);
    }
  });

export default router;
