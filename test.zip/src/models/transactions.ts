import Client from '../database';

export type Transaction = {
    transaction_id?:number;
  vehicle_id :string;
    vehicle_image: string;
    place:string;
    adjustment_date:string;
    adjustment_time: string;
    fine: number;
    payment_date: string;
    payment_status: string;
};

export class transactionStore {
    async create(u: Transaction): Promise<Transaction> {
        try {
          // const now =new Date().toLocaleString().split(",");
          const conn = await Client.connect();
          const sql =
            'INSERT INTO transactions ( vehicle, vehicle_image, place, adjustment_date ,adjustment_time ,fine ,payment_date ,payment_status ) VALUES($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *';
          const vehicle = await conn.query(sql, [
            u.vehicle_id,
            u.vehicle_image,
            u.place,
            u.adjustment_date,
            u.adjustment_time,
            u.fine,
            u.payment_date,
            u.payment_status,
            ]);
          conn.release();
          return vehicle.rows[0];
        } catch (err) {
          throw new Error(`Cannot Create the transaction. ${err}.`);
        }
      }
      async index(): Promise<Transaction[]> {
        try {
          const conn = await Client.connect();
          const sql = 'SELECT * FROM transactions';
          const transactions = await conn.query(sql);
          conn.release();
          return transactions.rows;
        } catch (err) {
          throw new Error(`Cannot Display The transactions. ${err}.`);
        }
      }
      async show(id: string): Promise<Transaction> {
        try {
          const conn = await Client.connect();
          const sql = 'SELECT * FROM transactions WHERE transaction_id = $1';
          const vehicle = await conn.query(sql, [id]);
          conn.release();
          return vehicle.rows[0];
        } catch (err) {
          throw new Error(`Cannot Display The Specific transaction. ${err}.`);
        }
      }
      async showVehicleTransactions(id: string): Promise<Transaction[]> {
        try {
          const conn = await Client.connect();
          const sql = 'SELECT * FROM transactions WHERE vehicle = $1';
          const vehicle = await conn.query(sql, [id]);
          conn.release();
          const vehicles= vehicle.rows;
          return vehicles;
        } catch (err) {
          throw new Error(`Cannot Display The Specific Vehicle transactions. ${err}.`);
        }
      }
      // async update(u: Transaction, id: string): Promise<Transaction> {
      //   try {
      //     const sql =
      //       'UPDATE transactions SET vehicle_id=$1, vehicle_image=$2, place=$3, adjustment_date=$4, adjustment_time=$5, fine=$6, payment_date=$7, payment_status=$8 WHERE transaction_id=$9 RETURNING *';
      //     const conn = await Client.connect();
      //     const result = await conn.query(sql, [
      //       u.vehicle_id,
      //       u.vehicle_image,
      //       u.place,
      //       u.adjustment_date,
      //       u.adjustment_time,
      //       u.fine,
      //       u.payment_date,
      //       u.payment_status,
      //       u.transaction_id,
      //     ]);
      //     const vehicle = result.rows[0];
      //     conn.release();
      //     return vehicle;
      //   } catch (err) {
      //     throw new Error(`Cannot update Transaction Details. ${err}.`);
      //   }
      // }
      async delete(id: number): Promise<Transaction> {
        try {
          const sql = 'DELETE FROM transactions WHERE transaction_id=($1)';
          const conn = await Client.connect();
          const vehicle = await conn.query(sql, [id]);
          conn.release();
          return vehicle.rows[0];
        } catch (err) {
          throw new Error(`Cannot Delete The Transaction. ${err}.`);
        }
      }
      async paidId(id: string): Promise<Transaction> {
        try {
          const conn = await Client.connect();
          const sql = 'UPDATE transactions SET payment_status=$2 WHERE transaction_id=$1 RETURNING *';
          const vehicle = await conn.query(sql, [id,"paid"]);
          conn.release();
          return vehicle.rows[0];
        } catch (err) {
          throw new Error(`Cannot Display The Specific transaction. ${err}.`);
        }
      }
    }
